updated version for the readexcel and checkaddress:
check_address.xaml
split_address.xaml
readexcel_new2.xaml